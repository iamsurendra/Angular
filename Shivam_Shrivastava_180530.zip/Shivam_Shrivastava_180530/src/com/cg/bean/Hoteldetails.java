package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.Table;

@Entity
public class Hoteldetails implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="rating")
	private String rating;
	
	@Column(name="rate")
	private long rate;
	
	@Column(name="availablerooms")
	private int availablerooms;
	

	
	public int getId() {
		return id;
	}
	public void setId(int id){
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public long getRate() {
		return rate;
	}
	public void setRate(long rate) {
		this.rate = rate;
	}
	public int getAvailablerooms() {
		return availablerooms;
	}
	public void setAvailablerooms(int availablerooms) {
		this.availablerooms = availablerooms;
	}
	@Override
	public String toString() {
		return "Hotel [id=" + id + ", name=" + name + ", rating=" + rating
				+ ", rate=" + rate + ", availablerooms=" + availablerooms + "]";
	}
	
	
	
}
