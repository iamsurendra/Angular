package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Hoteldetails;
import com.cg.dao.BookingDAOImpl;
import com.cg.dao.IBookingDAO;


@Service
@Transactional
public class BookingServiceImpl implements IBookingService{
	
	@Autowired
	private IBookingDAO dao;

	public BookingServiceImpl() {
		dao = new BookingDAOImpl(); 
	}

	@Override
	public List<Hoteldetails> viewAllHotels() {
		// TODO Auto-generated method stub
		return dao.viewAllHotels();
	}

}
