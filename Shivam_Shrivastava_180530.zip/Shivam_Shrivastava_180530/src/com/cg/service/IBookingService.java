package com.cg.service;

import java.util.List;

import com.cg.bean.Hoteldetails;



public interface IBookingService {
	
	public List<Hoteldetails> viewAllHotels();

}
