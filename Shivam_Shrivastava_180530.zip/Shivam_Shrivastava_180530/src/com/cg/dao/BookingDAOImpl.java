package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Hoteldetails;


@Repository
public class BookingDAOImpl implements IBookingDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Hoteldetails> viewAllHotels() {
		String qry = "SELECT s FROM Hoteldetails s";
		TypedQuery<Hoteldetails> query = entityManager.createQuery(
				qry, Hoteldetails.class);
		return query.getResultList();
	}

}
