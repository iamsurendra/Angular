package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Hoteldetails;
import com.cg.service.IBookingService;




@Controller
public class BookingController {
	
	@Autowired
	private IBookingService bookingservice;
	
    @RequestMapping("/index.obj")
	public String getHomePage(Model model){	
    	model.addAttribute("hoteldetailsList",bookingservice.viewAllHotels());
		
		return "index";
	}
	
	@RequestMapping(value="/displayHotel.obj")
	public String nextPage(@RequestParam String name, Model model)
	{
		try{
			List<Hoteldetails> list = bookingservice.viewAllHotels();
			if (list.isEmpty()) {
				String msg = "There are no Donors";
				model.addAttribute("msg", msg);
				return "myError";
		}		
		model.addAttribute("list", list);
		return "HotelBooking";
		}
		catch(DataAccessException dataAccessException)
		{
			model.addAttribute("msg","Technical Problem..Please Try Later!!");
			return "myError";
		}
	}

}
