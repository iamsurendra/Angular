package com.cg.repo;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Customer;
import com.cg.entity.Transactions;
import com.cg.exception.AccountException;



@Repository
@Transactional
public class AccountDAO implements IAccountDAO {

	
	@PersistenceContext 
	private EntityManager entityManager;
	
//	@Autowired
//	private Transactions transaction;

	Transactions transaction = null;
	
	public Transactions setTransactionDetails(int actNum,String trnsType,double initialAmt,double transAmtAmt,double finalAmt)
	{
		transaction= new Transactions();
		
		transaction.setActNum(actNum);
		transaction.settDate(""+new Timestamp(new java.util.Date().getTime()));
		transaction.setTrnsType(trnsType);
		transaction.setInitialAmt(initialAmt);
		transaction.setTransAmt(transAmtAmt);
		transaction.setFinalAmt(finalAmt);
		
		entityManager.persist(transaction);
		
		return transaction;
	}

	
	@Override
	public Customer createAccount(Customer customer) {
		entityManager.persist(customer);
		setTransactionDetails(customer.getAccNum(),"Credit",0,customer.getActBal(),customer.getActBal());
		return customer;
	}

	@Override
	public Customer showBal(int actNum) throws AccountException {
		Customer customer=entityManager.find(Customer.class, actNum);
		if(customer != null)
			return customer;
		else
			throw new AccountException("Account Not Found For ActNum:: "+actNum);
	}

	@Override
	public double withdraw(int actNum,double amt) throws AccountException {
		Customer customer=entityManager.find(Customer.class, actNum);
		if(customer != null) {
			double initBal=customer.getActBal();
			if(amt <=initBal )
			{
				double finalBal = initBal - amt;
				customer.setActBal(finalBal);
				
				setTransactionDetails(customer.getAccNum(),"Debit",initBal,amt,finalBal);	
				entityManager.merge(customer);
				
				return finalBal;
			}
			else
				throw new AccountException("Insufficient Funds:: Available Bal:: "+initBal);
		}
		else
			throw new AccountException("Account Not Found For ActNum:: "+actNum);
	}

	@Override
	public double deposite(int actNum,double amt) throws AccountException{
		Customer customer=entityManager.find(Customer.class, actNum);
		if(customer != null) {
			double initBal=customer.getActBal();
			if(amt <=initBal )
			{
				double finalBal = initBal + amt;
				customer.setActBal(finalBal);
				
				setTransactionDetails(customer.getAccNum(),"Credit",initBal,amt,finalBal);
				entityManager.merge(customer);
				
				return finalBal;
			}
			else
				throw new AccountException("Insufficient Funds:: Available Bal:: "+initBal);
		}
		else
			throw new AccountException("Account Not Found For ActNum:: "+actNum);
			
	}

	@Override
	public double fundTransfer(int fromActNum, int toActNum, double amt) throws AccountException {
		if(fromActNum != toActNum)
		{
			Customer fromCust=entityManager.find(Customer.class, fromActNum);
			if(fromCust != null)
			{
				double initFromBal= fromCust.getActBal();
				
				Customer toCust=entityManager.find(Customer.class, toActNum);
				if(toCust != null)
				{
					
					if(amt<=initFromBal)
					{
						double finalFromBal = initFromBal - amt;
						fromCust.setActBal(finalFromBal);
						setTransactionDetails(fromCust.getAccNum(),"Debit",initFromBal,amt,finalFromBal);
						entityManager.merge(fromCust);
						
						
						double initToBal= toCust.getActBal();
						double finalToBal = initToBal + amt;
						toCust.setActBal(finalToBal);
						setTransactionDetails(toCust.getAccNum(),"Credit",initToBal,amt,finalToBal);
						entityManager.merge(toCust);
						return finalFromBal;
					}
					else
						throw new AccountException("Insufficient Funds:: Available Bal:: "+initFromBal);
				}
				else
					throw new AccountException("Account Not Found For ActNum:: "+toActNum);
			}
			else
				throw new AccountException("Account Not Found For ActNum:: "+fromActNum);
		}
		else
			throw new AccountException("From act Num & To Act Num CANNOT BE SAME...");
	}

	@Override
	public List<Transactions> printTransaction(int actNum)  throws AccountException{
	
		String qStr = "SELECT transaction FROM Transactions transaction WHERE transaction.actNum=:pActNum";
		TypedQuery<Transactions> query = entityManager.createQuery(qStr, Transactions.class);
		query.setParameter("pActNum", actNum);
		List<Transactions> transactionList = query.getResultList();
		
		if(transactionList.isEmpty())
			throw new AccountException("Account Not Found For ActNum:: "+actNum);	
		else
			return transactionList;
		
	}

}






