package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.entity.Transactions;
import com.cg.exception.AccountException;

public interface IAccountService {
	
	Customer createAccount(Customer customer);
	Customer showBal(int actNum) throws AccountException;
	double withdraw(int actNum,double amt) throws AccountException;
	double deposite(int actNum,double amt) throws AccountException;
	double fundTransfer(int fromActNum,int toActNum,double amt) throws AccountException;
	List<Transactions> printTransaction(int actNum) throws AccountException;
	

}
