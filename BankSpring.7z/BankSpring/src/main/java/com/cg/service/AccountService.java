package com.cg.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Customer;
import com.cg.entity.Transactions;
import com.cg.exception.AccountException;
import com.cg.repo.AccountDAO;
import com.cg.repo.IAccountDAO;


@Service
@Transactional
public class AccountService implements IAccountService {

	@Autowired
	private IAccountDAO dao;
	
	@Override
	public Customer createAccount(Customer customer) {
		// TODO Auto-generated method stub
		return dao.createAccount(customer);
	}

	@Override
	public Customer showBal(int actNum) throws AccountException {
		// TODO Auto-generated method stub
		return dao.showBal(actNum);
	}

	@Override
	public double withdraw(int actNum,double amt) throws AccountException{
		// TODO Auto-generated method stub
		return dao.withdraw(actNum,amt);
	}

	@Override
	public double deposite(int actNum,double amt) throws AccountException{
		// TODO Auto-generated method stub
		return dao.deposite(actNum,amt);
	}

	@Override
	public double fundTransfer(int fromActNum, int toActNum, double amt) throws AccountException{
		// TODO Auto-generated method stub
		return dao.fundTransfer(fromActNum, toActNum, amt);
	}

	@Override
	public List<Transactions> printTransaction(int actNum) throws AccountException {
		// TODO Auto-generated method stub
		return dao.printTransaction(actNum);
	}	
	
}
	


