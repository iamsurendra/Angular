package com.cg.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name="BankJPA")
@SequenceGenerator(name="flseq", sequenceName="plane_seq" ,initialValue=552821)
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;	

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="flseq")
	@Column(length=10)
	private int accNum;
	@Column(length=20)
	private String name;
	@Column(length=10)
	private long phNum;
	@Column(length=30)
	private String addr;
	@Column(length=30)
	private String email;
	@Column(length=15)
	private String dob;
	@Column(length=7)
	private String gender;
	
	@Column(length=10)
	private String ifsc;
	@Column(length=8)
	private String branch;
	@Column
	private double actBal;
	
	public Customer(String name, int phNum, String addr, String email,
			String dob, String gender) {
		
		this.name = name;
		this.phNum = phNum;
		this.addr = addr;
		this.email = email;
		this.dob = dob;
		this.gender = gender;
	
		this.ifsc = "XYZ000854";
		this.branch = "Airoli";
		
		
		
	}
	public Customer() {
		
		this.ifsc = "XYZ000854";
		this.branch = "Airoli";
		
		
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhNum() {
		return phNum;
	}
	public void setPhNum(long phNum) {
		this.phNum = phNum;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
	public int getAccNum() {
		return accNum;
	}

	public String getIfsc() {
		return ifsc;
	}

	public String getBranch() {
		return branch;
	}

	public void setAccNum(int accNum) {
		this.accNum = accNum;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getActBal() {
		return actBal;
	}

	public void setActBal(double actBal) {
		this.actBal = actBal;
	}
	@Override
	public String toString() {
		return "Customer [accNum=" + accNum + ", name=" + name + ", phNum=" + phNum + ", addr=" + addr + ", email="
				+ email + ", dob=" + dob + ", gender=" + gender + ", ifsc=" + ifsc + ", branch=" + branch + ", actBal="
				+ actBal + "]";
	}
	

}
