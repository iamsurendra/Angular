package com.cg.entity;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Service;

@Entity
@Table(name="Transaction")
public class Transactions implements Serializable{
	private static final long serialVersionUID = 1L;	
	
	@Id
	@GeneratedValue
	@Column(length=10)
	private int tranId;
	@Column(length=10)
	private int actNum;
	@Column(length=20)
	private double initialAmt;
	@Column(length=20)
	private double transAmt;
	@Column(length=20)
	private double finalAmt;
	@Column(length=25)
	private String tDate;
	@Column(length=10)
	private String trnsType;
	
	public Transactions() {
	}
	
	
	public int getTranId() {
		return tranId;
	}

	public void setTrandId(int tranId) {
		this.tranId = tranId;
	}

	public int getActNum() {
		return actNum;
	}
	public void setActNum(int actNum) {
		this.actNum = actNum;
	}
	public double getInitialAmt() {
		return initialAmt;
	}
	public void setInitialAmt(double initialAmt) {
		this.initialAmt = initialAmt;
	}
	public double getTransAmt() {
		return transAmt;
	}
	public void setTransAmt(double transAmt) {
		this.transAmt = transAmt;
	}
	public double getFinalAmt() {
		return finalAmt;
	}
	public void setFinalAmt(double finalAmt) {
		this.finalAmt = finalAmt;
	}
	
	
	public String gettDate() {
		return tDate;
	}


	public void settDate(String tDate) {
		this.tDate = tDate;
	}


	public void setTranId(int tranId) {
		this.tranId = tranId;
	}


	public String getTrnsType() {
		return trnsType;
	}
	
	public void setTrnsType(String trnsType) {
		this.trnsType = trnsType;
	}


	@Override
	public String toString() {
		return "Transactions [actNum=" + actNum + ", initialAmt=" + initialAmt
				+ ", transAmt=" + transAmt + ", finalAmt=" + finalAmt
				+ ", date=" + tDate + ", trandId=" + tranId + "]";
	}
	
		

}
