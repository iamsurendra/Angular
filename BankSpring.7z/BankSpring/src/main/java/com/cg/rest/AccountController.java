package com.cg.rest;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Customer;
import com.cg.entity.Transactions;
import com.cg.exception.AccountException;
import com.cg.service.IAccountService;



@RestController
public class AccountController {

	@Autowired
	private IAccountService service;
	
	
	@PostMapping(value="/add", consumes="application/json")
	public Customer add(@RequestBody Customer customer)
	{
		
		return service.createAccount(customer);
	}
	

	@GetMapping(value="/showBal/{actNum}", produces="application/json")
	public double showBal(@PathVariable int actNum) throws AccountException
	{
		Customer customer=service.showBal(actNum);
		return customer.getActBal();
	}
	
	@GetMapping(value="/withdraw", produces="application/json")
	public double withdraw(@RequestParam("actNum") int actNum , @RequestParam("amt") double amt) throws AccountException
	{
		double finalBal = service.withdraw(actNum , amt);
		return finalBal;
	}
	
	@GetMapping(value="/deposit", produces="application/json")
	public double deposit(@RequestParam("actNum") int actNum , @RequestParam("amt") double amt) throws AccountException
	{
		double finalBal = service.deposite(actNum , amt);
		return  finalBal;
	}
	
	@GetMapping(value="/transfer", produces="application/json")
	public double fundTransfer(@RequestParam("fromActNum") int fromActNum ,@RequestParam("toActNum") int toActNum, @RequestParam("amt") double amt) throws AccountException
	{
		double finalBal = service.fundTransfer(fromActNum,toActNum , amt);
		return finalBal;
	}
	
	
	@GetMapping(value="/print", produces="application/json")
	public List<Transactions> printTransactions(@RequestParam("actNum") int actNum ) throws AccountException
	{
		return service.printTransaction(actNum);
	}
}














