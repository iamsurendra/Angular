package com.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;







import com.spring.dao.hotDAO;

import com.spring.model.Hotel;


@Service
@Transactional


public class HotServiceImpl implements HotService
{
	@Autowired
	hotDAO studao;

	@Override
	public List<Hotel> getAll()
	{
		return studao.getAll();
	}

	@Override
	public int addWoodlands(Hotel s) {
		// TODO Auto-generated method stub
		studao.addWoodlands(s);
		return s.getId();
	}

	@Override
	public int addGinger(Hotel s) {
		// TODO Auto-generated method stub
		studao.addGinger(s);
		return s.getId();
	}

	@Override
	public int addVivanta(Hotel s) {
		// TODO Auto-generated method stub
		studao.addVivanta(s);
		return s.getId();
	}

	@Override
	public int addHilton(Hotel s) {
		// TODO Auto-generated method stub
		studao.addHilton(s);
		return s.getId();
	}

	
}
