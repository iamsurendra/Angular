package com.spring.service;


import java.util.List;

import com.spring.model.Hotel;




public interface HotService
{
	public int addWoodlands(Hotel s);
    public int addGinger(Hotel s);
     public int addVivanta(Hotel s);
     public int addHilton(Hotel s);
	
	public List<Hotel> getAll();
}
