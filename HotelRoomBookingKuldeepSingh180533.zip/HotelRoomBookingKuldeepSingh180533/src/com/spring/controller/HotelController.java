package com.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;




import com.spring.exception.HotelException;

import com.spring.model.Hotel;

import com.spring.service.HotService;



@Controller
public class HotelController
{
	Hotel stu2 ;
	Hotel stu = new Hotel();
	@Autowired
	HotService service;
	
	@RequestMapping("/home")
	public String showHome()
	{
		return "HotelDetails";
	}
	
	@RequestMapping(value="/addWoodlands",method=RequestMethod.GET)
	public String addWoodlands(Model model,HttpServletRequest request)
	{
		String view = "addWoodlands";
		
		
		
		model.addAttribute("student", new Hotel());

		 return view;
		
	}
	@RequestMapping(value="/addHilton",method=RequestMethod.GET)
	public String addHilton(Model model,HttpServletRequest request)
	{
		String view = "addHilton";
		
		
		
		model.addAttribute("student", new Hotel());

		 return view;
		
	}
	@RequestMapping(value="/addVivanta",method=RequestMethod.GET)
	public String addVivana(Model model,HttpServletRequest request)
	{
		String view = "addVivanta";
		
		
		
		model.addAttribute("student", new Hotel());

		 return view;
		
	}
	
		
	
	
	@RequestMapping(value="/addGinger",method=RequestMethod.GET)
	public String addGinger(Model model,HttpServletRequest request)
	{
		String view = "addGinger";
		
		
		
		model.addAttribute("student", new Hotel());

		 return view;
		
	}

	@RequestMapping(value="/display")
	public String processShow(Model model) throws HotelException
	{
		String view="";
		List<Hotel> list = service.getAll();
	  if(list !=null)
	  {
		  model.addAttribute("listStu", list);
		  view="show";
		  
	  }else
	  {
		  throw new HotelException("display is not correct");
		  
	  }
	   return view;
	  
	}
}
