package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Hotel")
public class Hotel
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length=10)
	private int id;
	
	@Column(length=30)
	@Size(min=3,max=10,message="the name should not be empty and min must be 3 and max bust be 30")
	private String name;
	
	@Column(length=10)
	@NotEmpty(message="the rating can not bt  empty")
	private String rating;
	
	@Column(length=8)
	@NotNull(message="please enter rate ")
	//@Min(message="Minimum must be 7",value=7)
	//@Max(message="Maximum must be 10",value=10)
	private int  rate;
	
	@Column(length=10)
	@NotEmpty(message="no of available rooms are")
	private int  availablerooms ;
	
	public Hotel() {
		super();
	}
	public Hotel(int id, String name, String rating, int rate, int availablerooms) {
		super();
		this.id = id;
		this.name = name;
		this.rating = rating;
		this.rate = rate;
		this.availablerooms = availablerooms;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public int getAvailablerooms() {
		return availablerooms;
	}
	public void setAvailablerooms(int availablerooms) {
		this.availablerooms = availablerooms;
	}
	

}
