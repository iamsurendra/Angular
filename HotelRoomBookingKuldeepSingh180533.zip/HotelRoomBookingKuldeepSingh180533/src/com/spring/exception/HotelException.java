package com.spring.exception;

public class HotelException extends Exception
{

	public  HotelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
