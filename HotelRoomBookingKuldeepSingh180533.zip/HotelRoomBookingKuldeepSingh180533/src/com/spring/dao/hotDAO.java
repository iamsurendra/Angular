package com.spring.dao;

import java.util.List;


import com.spring.model.Hotel;



public interface hotDAO 
{
	public int addWoodlands(Hotel s);
    public int addGinger(Hotel s);
     public int addVivanta(Hotel s);
     public int addHilton(Hotel s);
	
	public List<Hotel> getAll();
	
	//public void updateStu(Student stu,Student stus);
	//public void delStu(int id)throws PatientException;

}
