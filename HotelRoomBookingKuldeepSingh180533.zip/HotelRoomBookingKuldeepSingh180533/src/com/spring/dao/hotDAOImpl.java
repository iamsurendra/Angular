package com.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.spring.model.Hotel;




@Repository
public class hotDAOImpl implements hotDAO
{
	@PersistenceContext
	EntityManager manager;

	

	@Override
	public List<Hotel> getAll() 
	{
		Query query = manager.createQuery("select stu from Hotel stu");
		List<Hotel> list = query.getResultList();
		return list;
	}

	
	@Override
	public int addWoodlands(Hotel s) {
		// TODO Auto-generated method stub
		manager.persist(s);
		return s.getId();
	}

	@Override
	public int addGinger(Hotel s) {
		// TODO Auto-generated method stub
		manager.persist(s);
		return s.getId();
	}

	@Override
	public int addVivanta(Hotel s) {
		// TODO Auto-generated method stub
		manager.persist(s);
		return s.getId();
	}

	@Override
	public int addHilton(Hotel s) {
		// TODO Auto-generated method stub
		manager.persist(s);
		return s.getId();
	}

	
	
}
