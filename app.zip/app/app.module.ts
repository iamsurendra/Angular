﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';;
import { ListComponent } from './list/list.component'
import {Routes,RouterModule} from '@angular/router';;
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
;
import { AddAlbumComponent } from './add-album/add-album.component';

const appRoutes:Routes=[
    {path:'list', component:ListComponent},
    {path:'addalbum', component:AddAlbumComponent}
   
    ]
@NgModule({
    imports: [
        BrowserModule,
        RouterModule.forRoot(appRoutes),
        FormsModule,
        ReactiveFormsModule
        
    ],
    declarations: [
        AppComponent,
        ListComponent,
        AddAlbumComponent],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }