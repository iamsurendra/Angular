import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AlbumDataService } from '../services/album-data.service';

@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  addForm:FormGroup;
  

  constructor(private router: Router, private albumService: AlbumDataService) { }

  ngOnInit() {
    this.addForm=new FormGroup({
     albumId:new FormControl('',[Validators.required, Validators.pattern('[0-9]{1,15}')]),
      title:new FormControl('',[Validators.required]), 
      artist:new FormControl('',[Validators.required]),
      price: new  FormControl('',[Validators.required])
     })
  }

 
  addAlbumToArray(form){
    console.log(form.value);
    this.albumService.addAlbum(form.value)
    this.router.navigate(['/list']);
    }
 
  }


