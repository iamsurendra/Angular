import { Component, OnInit } from '@angular/core';
import { Album } from '../viewmodel/Album';
import { AlbumDataService } from '../services/album-data.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  
  album:Album[]=[];
  
  constructor(private _albumlist:AlbumDataService) { }

  
  ngOnInit() {
    
    this.album=this._albumlist.getAlbums();
  }

 
  deleteAlbumFromService(album:Album){
    confirm("Are you sure you want to delete?");
    this._albumlist.deleteAlbum(album);
  }
}
