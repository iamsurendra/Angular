export class Album{
    albumId:number;
    title:string;
    artist:string;
    price:string;
}