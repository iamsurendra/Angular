import { Injectable } from '@angular/core';
import { Album } from '../viewmodel/Album';

@Injectable({
  providedIn: 'root'
})
export class AlbumDataService {

  albums:Album[]=[
    {albumId:101, title:'Hotel California', artist:'Eagles', price:'1000' },
    {albumId:102, title:'True Blue', artist:'Madona', price:'2000' },
    {albumId:103, title:'Dookie', artist:'Green Day', price:'3000' }

  ];

  getAlbums(){
    return this.albums;
  }


  addAlbum(album1: Album) {
    this.albums.push(album1);
  }
  
  deleteAlbum(album2:Album){
    let indexPosition=this.albums.indexOf(album2);
  return this.albums.splice(indexPosition, 1)
  }
  constructor() { }
}
