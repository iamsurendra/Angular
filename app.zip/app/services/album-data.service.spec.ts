import { TestBed, inject } from '@angular/core/testing';

import { AlbumDataService } from './album-data.service';

describe('AlbumDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AlbumDataService]
    });
  });

  it('should be created', inject([AlbumDataService], (service: AlbumDataService) => {
    expect(service).toBeTruthy();
  }));
});
