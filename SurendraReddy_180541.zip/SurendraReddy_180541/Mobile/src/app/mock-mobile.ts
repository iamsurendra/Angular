
import {Mobile} from './mobile';
export const MOBILES: Mobile[]=[];