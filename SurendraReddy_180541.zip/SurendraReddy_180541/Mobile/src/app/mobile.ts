export class Mobile{
    public mobileId: number;
   public mobileName: string;
   public mobilePrice: number;
    public mobileBrand : string;
   
}