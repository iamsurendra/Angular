import { Injectable } from '@angular/core';
import { MobileModel } from '../model/MobileModel';

@Injectable({
  providedIn: 'root'
})
export class MobileServiceService {
mobile:MobileModel[]=[];

mobileArray:MobileModel[];
  constructor() {
    this.mobile=[];
   }
  //add data in database
  insertMobile(mobile: MobileModel){
    this.mobile.push(mobile);
  }

  //return whole database
  getList(): MobileModel[]{
    return this.mobile;
  }
  //delete a entry
  deleteMobile(index:number){
    return this.mobile.splice(index,1);
  }

  searchMobile(id:number){
    var res=this.mobile.find(x=>x.mobileId==id);
    return res;
    }
}


  