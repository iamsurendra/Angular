import { Component, OnInit } from '@angular/core';
import { MobileModel } from '../model/MobileModel';
import { MobileServiceService } from '../service/mobile-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
mobile:MobileModel[];
  constructor(private mobileservice :MobileServiceService,private router:Router) { }

  ngOnInit() {
    this.mobile=this.mobileservice.getList();
  }
  delete(index:number){
    var ans = confirm("Are you sure You want to delete?")
    if(ans){
      this.mobileservice.deleteMobile(index);
    }
  }
}
