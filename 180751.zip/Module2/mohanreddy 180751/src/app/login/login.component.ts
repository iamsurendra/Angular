import { Component, OnInit } from '@angular/core';
import { a } from '@angular/core/src/render3';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  registerForm: FormGroup;
    submitted = false;

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            name: ['', [Validators.required, Validators.pattern('[a-zA-z][a-zA-Z .]+'), ]],
            address: ['', Validators.required],
            pincode: ['', [Validators.required, Validators.pattern('[0-9]{6}')] ],
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        alert('SUCCESSFULLY VALIDATED!! :-)\n\n ' + JSON.stringify(this.registerForm.value) )
    }
}