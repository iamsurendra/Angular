﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';;
import { LoginComponent } from './login/login.component'
import { FormsModule} from '@angular/forms';
import { ReactiveFormsModule  } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
    { path: '', component: LoginComponent },
]

@NgModule({
    imports: [
        BrowserModule,
        RouterModule.forRoot(appRoutes),
        FormsModule,
        ReactiveFormsModule,

    ],
    declarations: [
        AppComponent
,
        LoginComponent		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }