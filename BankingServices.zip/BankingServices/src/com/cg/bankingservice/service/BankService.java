package com.cg.bankingservice.service;

import java.util.ArrayList;

import com.cg.bankingservice.dto.AdminRegister;
import com.cg.bankingservice.dto.UserRegister;
import com.cg.bankingservice.exception.BankException;

public interface BankService {

	int addAdmin(AdminRegister emp)throws BankException;
	AdminRegister getAdminById(int empId)throws BankException;
	boolean validateName(String name);
	boolean validatePhone(String mobile);	
	int addUser(UserRegister emp)throws BankException;
	UserRegister getUserById(int empId)throws BankException;
	
	ArrayList<AdminRegister>getAllAdmin()throws BankException;
	ArrayList<UserRegister>getAllUser()throws BankException;
	UserRegister removeUser(int accountnumber)throws BankException;

	public double deposit(String username,String password,double amount) throws BankException;
	boolean validateSalary(double accountnumber);
}
