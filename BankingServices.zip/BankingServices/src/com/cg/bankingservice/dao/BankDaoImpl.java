package com.cg.bankingservice.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.bankingservice.dto.AdminRegister;
import com.cg.bankingservice.dto.UserRegister;
import com.cg.bankingservice.exception.BankException;
import com.cg.bankingservice.util.DBUtil;
import com.cg.logger.MyLogger;

public class BankDaoImpl implements BankDao{
	
	Connection con;
	Logger logger;
	
	
	public BankDaoImpl()
	{
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}

	public int getAdminId()throws BankException
	{
		logger.info("In getAdminId");
		int id = 0;
		String qry = "SELECT adminId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("Got Admin User With Id"+id);
			}
			}
			catch(SQLException e)
			{
				logger.error("Error"+e.getMessage());
				throw new BankException(e.getMessage());
			}
			logger.info("Completed getAdminId");
			return id;
		
	}
	@Override
	public int addAdmin(AdminRegister emp) throws BankException {
		// TODO Auto-generated method stub
		logger.info("In Add AdminRegister");
		logger.info("Input is "+emp);
		int id = 0;
		String qry = "INSERT INTO AdminRegister VALUES(adminId_seq.NEXTVAL,?,?,?,?,?)";
		String name = emp.getAdminName();
		String username = emp.getAdminUserName();
		String password = emp.getPassword();
		String mobile = emp.getMobile();
		String address = emp.getAddress();
		
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setString(2, username);
			pstmt.setString(3, password);
			pstmt.setString(4, mobile);
			pstmt.setString(5, address);
			
			
			
			
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getAdminId();
				logger.info("Inserted successfully and Id is = "+id);
			}
			else
				throw new BankException("unable to insert"+emp);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new BankException(e.getMessage());
		}
		return id;
		
		
		
		
		
	}

	
	@Override
	public AdminRegister getAdminById(int adminId) throws BankException {
		// TODO Auto-generated method stub
		AdminRegister emp = null;
		String qry = "SELECT * FROM AdminRegister WHERE adminId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, adminId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String mobile = rs.getString(5);
				String address = rs.getString(6);




				emp = new AdminRegister(id,name,username,password,mobile,address);
			}
			else
				throw new BankException("Admin with id "+adminId+"not found");
		}
		catch(SQLException e)
		{
			throw new BankException(e.getMessage());
		}
		return emp;
	}
	
	
	@Override
	public ArrayList<AdminRegister> getAllAdmin() throws BankException {
		// TODO Auto-generated method stub
		ArrayList<AdminRegister>list = new ArrayList<AdminRegister>();
		String qry = "SELECT * FROM AdminRegister";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username=rs.getString(3);
				String password=rs.getString(4);
				String mobile= rs.getString(5);
				String address=rs.getString(6);
				
				AdminRegister emp = new AdminRegister(id,name,username,password,mobile,address);
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new BankException(e.getMessage());
		}
		return list;
	}
	
	public int getUserId()throws BankException
	{
		logger.info("In getUserId");
		int id1 = 0;
		String qry = "SELECT userId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id1 = rs.getInt(1);
				logger.info("Got  User With account number"+id1);
			}
			}
			catch(SQLException e)
			{
				logger.error("Error"+e.getMessage());
				throw new BankException(e.getMessage());
			}
			logger.info("Completed getUserId");
			return id1;
		
	}
	@Override
	public int addUser(UserRegister emp) throws BankException {
		// TODO Auto-generated method stub
		logger.info("In Add UserRegister");
		logger.info("Input is "+emp);
		int id1 = 0;
		String qry = "INSERT INTO UserRegister VALUES(userId_seq.NEXTVAL,?,?,?,?,?,?)";
		String name = emp.getUserName();
		String username = emp.getUserName();
		String password = emp.getPassword();
		String mobile = emp.getMobile();
		String address = emp.getAddress();
		Double balance=emp.getBalance();
		
		
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setString(2, username);
			pstmt.setString(3, password);
			pstmt.setString(4, mobile);
			pstmt.setString(5, address);
			pstmt.setDouble(6, balance);
			
			
			
			
			
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id1 = getUserId();
				logger.info("Inserted successfully and Account Number  is = "+id1);
			}
			else
				throw new BankException("unable to insert"+emp);
			
		}
		catch(SQLException e)
		{
			logger.error("Error in insert = "+e.getMessage());
			throw new BankException(e.getMessage());
		}
		return id1;
		
		
		
		
		
	}

	
	@Override
	public UserRegister getUserById(int userId) throws BankException {
		// TODO Auto-generated method stub
		UserRegister emp = null;
		String qry = "SELECT * FROM UserRegister WHERE account_number=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String username = rs.getString(3);
				String password = rs.getString(4);
				String mobile = rs.getString(5);
				String address = rs.getString(6);
				Double balance=rs.getDouble(7);




				emp = new UserRegister(id,name,username,password,mobile,address,balance);
			}
			else
				throw new BankException("User with id "+userId+"not found");
		}
		catch(SQLException e)
		{
			throw new BankException(e.getMessage());
		}
		return emp;
	}

	@Override
	public AdminRegister removeAdmin(int empId) throws BankException {
		// TODO Auto-generated method stub
		AdminRegister emp = null;
		String qry = "DELETE FROM AdminRegister WHERE adminId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, empId);
			emp = getAdminById(empId);
			int row = pstmt.executeUpdate();
			if(emp==null)
			{
				throw new BankException("emp with id "+empId+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted Employee with Id "+empId);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new BankException(e.getMessage());
		}
		return emp;
	}
	@Override
	public UserRegister removeUser(int empid) throws BankException {
		// TODO Auto-generated method stub
		UserRegister emp = null;
		String qry = "DELETE FROM UserRegister WHERE accountnumber=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, empid);
			emp = getUserById(empid);
			int row = pstmt.executeUpdate();
			if(emp==null)
			{
				throw new BankException("emp with id "+empid+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted Employee with Id "+empid);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new BankException(e.getMessage());
		}
		return emp;
	}
	


@Override
public ArrayList<UserRegister> getAllUser() throws BankException {
	// TODO Auto-generated method stub
	ArrayList<UserRegister>list = new ArrayList<UserRegister>();
	String qry = "SELECT * FROM UserRegister";
	try
	{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(qry);
		while(rs.next())
		{
			int id = rs.getInt(1);
			String name = rs.getString(2);
			String username=rs.getString(3);
			String password=rs.getString(4);
			String mobile= rs.getString(5);
			String address=rs.getString(6);
			Double balance=rs.getDouble(7);
			
			UserRegister emp = new UserRegister(id,name,username,password,mobile,address,balance);
			list.add(emp);
		}
	}
	catch(SQLException e)
	{
		throw new BankException(e.getMessage());
	}
	return list;
}

}
