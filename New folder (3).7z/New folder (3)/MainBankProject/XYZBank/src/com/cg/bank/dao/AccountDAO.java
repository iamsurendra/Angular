package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Customer;
import com.cg.bank.exception.AccountException;
import com.cg.bank.util.BankDB;

public class AccountDAO implements IAccountDAO {

	HashMap<Long,Customer> custDb=BankDB.getCustDB();
	HashMap<Long,Account> actDb=BankDB.getActDB();
	
	@Override
	public Account createAccount(Customer customer) {
		// TODO Auto-generated method stub
		custDb.put(customer.getActDetails().getAccNum(),customer);
		
		actDb.put(customer.getActDetails().getAccNum(), customer.getActDetails());
		
		return customer.getActDetails();
	}

	@Override
	public Account showBal(long actNum) throws AccountException {
		// TODO Auto-generated method stub
		if(actDb.containsKey(actNum))
			return actDb.get(actNum);
		else	
			throw new AccountException("No Account Found with accoumt num: "+actNum);
		
	}

	@Override
	public double withdraw(long actNum,double amt) throws AccountException {
		// TODO Auto-generated method stub
		if(actDb.containsKey(actNum))
		{
			Account act = actDb.get(actNum);
			if(amt<=act.getActBal())
			{
				act.setActBal(act.getActBal()-amt);
				return act.getActBal();
			}
			else 
				throw new AccountException("Insufficient Funds:: Available bal = "+act.getActBal());
		}
		
		else 
			throw new AccountException("Account Not found with account number : "+actNum);
			
		
	}

	@Override
	public double deposite(long actNum,double amt) throws AccountException{
		// TODO Auto-generated method stub
		if(actDb.containsKey(actNum))
		{
			Account act = actDb.get(actNum);
			act.setActBal(act.getActBal()+amt);
			
			return act.getActBal();
		}
		
		else 
			throw new AccountException("Account Not found with account number : "+actNum);
			
	}

	@Override
	public double fundTransfer(long fromActNum, long toActNum, double amt) throws AccountException {
		// TODO Auto-generated method stub
		if(actDb.containsKey(fromActNum))
		{
			Account fromAct=actDb.get(fromActNum);
			if(actDb.containsKey(toActNum))
			{
				Account toAct=actDb.get(toActNum);
				if(fromActNum!=toActNum)
				{
					if(amt<=fromAct.getActBal())
					{
						fromAct.setActBal(fromAct.getActBal()-amt);
						toAct.setActBal(toAct.getActBal()+amt);
						return fromAct.getActBal();
					}
					else 
						throw new AccountException("Insufficient Funds:: Available bal = "+fromAct.getActBal());
				}
				else 
					throw new AccountException("From Account num & To-Account Num CANNOT BE SAME ");
			}
			else 
			{
				throw new AccountException("Account Not found with account number : "+toActNum);
			}
		}
		else 
			throw new AccountException("Account Not found with account number : "+fromActNum);
			
	}

	@Override
	public void printTransaction(long actNum) throws AccountException{
		// TODO Auto-generated method stub
		
	}
	
	
	

}
