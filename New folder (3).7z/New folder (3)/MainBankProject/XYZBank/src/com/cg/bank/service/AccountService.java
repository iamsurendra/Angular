package com.cg.bank.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Customer;
import com.cg.bank.dao.AccountDAO;
import com.cg.bank.dao.IAccountDAO;
import com.cg.bank.exception.AccountException;

public class AccountService implements IAccountService {

	IAccountDAO dao=new AccountDAO();
	@Override
	public Account createAccount(Customer customer) {
		// TODO Auto-generated method stub
		return dao.createAccount(customer);
	}

	@Override
	public Account showBal(long actNum) throws AccountException {
		// TODO Auto-generated method stub
		return dao.showBal(actNum);
	}

	@Override
	public double withdraw(long actNum,double amt) throws AccountException{
		// TODO Auto-generated method stub
		return dao.withdraw(actNum,amt);
	}

	@Override
	public double deposite(long actNum,double amt) throws AccountException{
		// TODO Auto-generated method stub
		return dao.deposite(actNum,amt);
	}

	@Override
	public double fundTransfer(long fromActNum, long toActNum, double amt) throws AccountException{
		// TODO Auto-generated method stub
		return dao.fundTransfer(fromActNum, toActNum, amt);
	}

	@Override
	public void printTransaction(long actNum) throws AccountException {
		// TODO Auto-generated method stub
		dao.printTransaction(actNum);
	}
	
	//Validation Methods
	@Override
	public boolean validateName(String userEnteredName) {
		
		boolean isNameValid = userEnteredName.matches(namePattern);
		return isNameValid;
	}
	
	/*
	@Override
	public boolean validateAge(String userEnterdAge){
		
		boolean isAgeValid = userEnterdAge.matches(agePattern);
		return isAgeValid;
	}*/
	
	@Override
	public boolean validatePhNum (String userEnterdPhNum){
		
		boolean isPhNumValid = userEnterdPhNum.matches(phNumPattern);
		return isPhNumValid;
		
	}
	@Override
	public boolean validateDate (String userEnterdDate)
	
	{
		
		if (userEnterdDate.trim().equals(""))
		{
		    return true;
		}
		/* Date is not 'null' */
		else
		{
		    /*
		     * Set preferred date format,
		     * For example MM-dd-yyyy, MM.dd.yyyy,dd.MM.yyyy etc.*/
		    SimpleDateFormat sdfrmt = new SimpleDateFormat("MM/dd/yyyy");
		    sdfrmt.setLenient(false);
		    /* Create Date object
		     * parse the string into date 
	             */
		    try
		    {
		        Date javaDate = sdfrmt.parse(userEnterdDate); 
		    }
		    /* Date format is invalid */
		    catch (ParseException e)
		    {
		        return false;
		    }
		    /* Return true if date format is valid */
		    return true;
		}
	   }
	@Override
	public boolean validateEmail (String userEnterdEmail){
		
		boolean isPhNumValid = userEnterdEmail.matches(emailPattern);
		return isPhNumValid;
	}

	@Override
	public boolean validateGender(String userEnterdGender) {
		// TODO Auto-generated method stub
		if(userEnterdGender.equalsIgnoreCase("male"))
		{
			return true;
		}
		else if(userEnterdGender.equalsIgnoreCase("female"))
		{
			return true;
		}
		else if(userEnterdGender.equalsIgnoreCase("other"))
		{
			return true;
		}
		return false;
	}
	
	@Override
	public boolean validateAmount(long userEnterdAmount)
	{
		// TODO Auto-generated method stub
		if(userEnterdAmount>=100 && userEnterdAmount<=50000)
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateWithdrawAmount(long userEnteredAmount) {
		// TODO Auto-generated method stub
		
		if(userEnteredAmount>0 && userEnteredAmount<=50000)
		{
			return true;
		}
		return false;
	}
	  
	
	
}
	


