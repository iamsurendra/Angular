package com.cg.bank.bean;

public class Account {
	static long num=5498761231L;
	private long accNum;
	private String ifsc;
	private String branch;
	private double actBal;
	
	
	public Account() {
		super();
		accNum = ++ num ;
		this.ifsc = "XYZ000854";
		this.branch = "Airoli";
	} 
	public long getAccNum() {
		return accNum;
	}
	
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	public double getActBal() {
		return actBal;
	}
	public void setActBal(double actBal) {
		this.actBal = actBal;
	}
	@Override
	public String toString() {
		return "Account [accNum= " + accNum+ " ifsc=" + ifsc + ", branch=" + branch + ", actBal=" + actBal + "]";
	}
	
	
	
}
