package com.cg.bank.exception;

public class AccountException extends Exception {
	
	private String message;

	public AccountException(String message) {
		super();
		this.message = message;
	}
	@Override
	public String getMessage() {
		return message;
	}


}
