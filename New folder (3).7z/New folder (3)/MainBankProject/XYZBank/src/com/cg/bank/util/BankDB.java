package com.cg.bank.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Customer;

public class BankDB {
	
	private static HashMap<Long,Customer>  custDB=new HashMap<Long,Customer>();
	
	private static HashMap<Long,Account>  actDB=new HashMap<Long,Account>();
	
	private static List<Account> transDB=new ArrayList<Account>();
	
	public static HashMap<Long,Customer> getCustDB()
	{
		return custDB;
	}

	public static HashMap<Long,Account> getActDB()
	{
		return actDB;
	}
	
	public static List<Account> getTransDB()
	{
		return transDB;
	}

}
