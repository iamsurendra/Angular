package com.cg.bank.dao;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Customer;
import com.cg.bank.exception.AccountException;

public interface IAccountDAO {

	Account createAccount(Customer customer);
	Account showBal(long actNum) throws AccountException;
	double withdraw(long actNum,double amt) throws AccountException;
	double deposite(long actNum,double amt) throws AccountException;
	double fundTransfer(long fromActNum,long toActNum,double amt) throws AccountException ;
	void printTransaction(long actNum) throws AccountException;
	
}
