package com.cg.bank.service;

import com.cg.bank.bean.Customer;
import com.cg.bank.exception.AccountException;

public interface IAccountService {
	
	String namePattern="[a-zA-Z]{4,20}";
	String agePattern="[0-9]{1,2}";
	String phNumPattern="[9876][0-9]{9}";
	String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
            "[a-zA-Z0-9_+&*-]+)*@" + 
            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
            "A-Z]{2,7}$"; 
	
	Customer createAccount(Customer customer);
	double showBal(long actNum) throws AccountException;
	double withdraw(long actNum,double amt) throws AccountException;
	double deposite(long actNum,double amt) throws AccountException;
	double fundTransfer(long fromActNum,long toActNum,double amt) throws AccountException;
	void printTransaction(long actNum) throws AccountException;
	
	
	public boolean validateName(String userEnteredName);
	public boolean validatePhNum (String userEnterdPhNum);
	public boolean validateDate (String userEnterdDate);
	public boolean validateEmail(String userEnterdEmail);
	public boolean validateGender(String userEnterdGender);
	public boolean validateAmount(long userEnterdAmount);
	public boolean validateWithdrawAmount(long userEnteredAmount);

}
