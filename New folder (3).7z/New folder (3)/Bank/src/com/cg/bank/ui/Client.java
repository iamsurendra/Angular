package com.cg.bank.ui;

import java.util.Scanner;

import com.cg.bank.bean.Customer;
import com.cg.bank.exception.AccountException;
import com.cg.bank.service.AccountService;
import com.cg.bank.service.IAccountService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IAccountService service=new AccountService();
		
		Scanner scan = new Scanner(System.in);
		int choice=0;
		String userEnteredName;
		//String userEnteredAge;
		String userEnteredPhNum;
		String userEnteredDate;
		String userEnteredAddress;
		String userEnteredEmail;
		String userEnteredGender;
		long userEnteredAmt;

		
		do{	
			
			System.out.println("Welcome to My Bank");
			
			System.out.println("1. Create New Acoount");
			
			System.out.println("2. Manage Account");
			
			System.out.println("<<<<<<=============================================================>>>>>>");
			
			System.out.println("enter your choice");
			choice = scan.nextInt();
			switch(choice)
			{
			case 1:
				while(true)
				{
					System.out.println("Enter Your Full Name::");
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("name should contain min 4 letters and max 20 letters, No special Char Allowed");
					System.out.println();
					userEnteredName=scan.next();
					boolean isNameValid= service.validateName(userEnteredName);
					if(isNameValid)
					break;
					else
					{
						System.out.println("Invalid Name:");
					}
				}
				
				while(true)
				{
					System.out.println("Enter your Phone Number::");
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("Phone num should be 10 digits and starts with 9/8/7/6");
					System.out.println();
					userEnteredPhNum=scan.next();
					boolean isPhNumValid= service.validatePhNum(userEnteredPhNum);
					if(isPhNumValid)
					break;
					else
					{
						System.out.println("Invalid Phone number:");
					}
				}
				while(true)
				{
					System.out.println("Enter your Date Of Birth::");
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("Date  format should be MM/dd/yyyy");
					System.out.println();
					userEnteredDate=scan.next();
					boolean isDateValid= service.validateDate(userEnteredDate);
					if(isDateValid)
					break;
					else
					{
						System.out.println("Invalid date");
					}
				}
				
				while(true)
				{
					System.out.println("Enter your Email::");
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("Email  format should be example@xyz.org");
					System.out.println();
					userEnteredEmail=scan.next();
					boolean isEmailValid= service.validateEmail(userEnteredEmail);
					if(isEmailValid)
					break;
					else
					{
						System.out.println("Invalid Email");
					}
				}
				
				while(true)
				{
					System.out.println("Enter your Gender::");
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("Gender should be male/female/other");
					System.out.println();
					userEnteredGender=scan.next();
					boolean isGenderValid= service.validateGender(userEnteredGender);
					if(isGenderValid)
					break;
					else
					{
						System.out.println("Gender is Invalid");
					}
				}
				
				while(true)
				{
					System.out.println("Enter Deposit amount::");
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("Deposit amount Should be minimum 100 Rs. and maximum 50000 Rs. ::");
					System.out.println();
					userEnteredAmt=scan.nextLong();
					boolean isAmtValid= service.validateAmount(userEnteredAmt);
					if(isAmtValid)
					break;
					else
					{
						System.out.println("Invalid Amount");
					}
				}
				
				System.out.println("Enter your Full address");
				System.out.println("<<<<<<=============================================================>>>>>>");
				System.out.println();
				userEnteredAddress=scan.next();
				
				Customer cust1=new Customer(userEnteredName,Long.parseLong(userEnteredPhNum),
						userEnteredAddress,userEnteredEmail,userEnteredDate,userEnteredGender,userEnteredAmt);
				
				Customer act1=service.createAccount(cust1);
				System.out.println("Account Created Successfully ::");
				System.out.println("----------------------------------------------------------------------------------");
				System.out.println();
				System.out.println("Your account details are::");
				System.out.println("Account Num: "+act1.getAccNum()+"\n"+"IFSC: "+act1.getIfsc()+"\n"+"Branch: "+act1.getBranch()+"\n"+"Account Bal: "+act1.getActBal());
				System.out.println();
				System.out.println("<<<<Thanks for Banking with us >>>>");
				break;
			case 2:
				do {
					System.out.println("1. Balance Enquiry");
					
					System.out.println("2. Withdraw Amount");
					
					System.out.println("3. Deposit amount");
					
					System.out.println("4. Transfer Funds");
					
					System.out.println("5. Account Statement");
					
					System.out.println("<<<<<<=============================================================>>>>>>");
					System.out.println("enter your choice");
					choice = scan.nextInt();
						switch(choice){	
										case 1:
												System.out.println("Enter your account number::");
												long actNum=scan.nextLong();
												try
												{
													double rslt=service.showBal(actNum);
													System.out.println("Your current account balance for account : ");
													System.out.println();
													System.out.println("Account Number : "+actNum+"  Available Balance : "+rslt);
												} 
												catch (AccountException e)
												{
													// TODO Auto-generated catch block
													System.out.println(e.getMessage());
												}
												break;
				
										case 2:
											System.out.println("Enter your account number to Withdraw :: ");
											long actNum1=scan.nextLong();
											while(true)
											{
												System.out.println("Enter Amount to Withdraw :: ");
												System.out.println("<<<<<<=============================================================>>>>>>");
												System.out.println("Withdraw amount Should be more than 0 and maximum 50000 Rs. ::");
												System.out.println();
												userEnteredAmt=scan.nextLong();
												boolean isAmtValid= service.validateWithdrawAmount(userEnteredAmt);
												if(isAmtValid)
													break;
												else
												{
													System.out.println("Invalid Amount");
												}
											}
				
											try {
												double actAftTrans=service.withdraw(actNum1, userEnteredAmt);
												System.out.println("Amount Withdrawn Successfully Rs: "+userEnteredAmt);
												System.out.println();
												//System.out.println("Transaction ID : "+actAftTrans.getInt(1));
												System.out.println("Your Currunt Balance : "+actAftTrans);
											} catch (AccountException e) {
												// TODO Auto-generated catch block
												System.out.println(e.getMessage());
											}
											break;
										case 3:
											System.out.println("Enter your account number to Deposite :: ");
											long actNum2=scan.nextLong();
											while(true)
											{
												System.out.println("Enter Amount to Deposite :: ");
												System.out.println("<<<<<<=============================================================>>>>>>");
												System.out.println("Deposite amount Should be more than 0 and maximum 50000 Rs. ::");
												System.out.println();
												userEnteredAmt=scan.nextLong();
												boolean isAmtValid= service.validateWithdrawAmount(userEnteredAmt);
												if(isAmtValid)
													break;
												else
												{
													System.out.println("Invalid Amount");
												}
											}
				
											try {
												double currBal=service.deposite(actNum2, userEnteredAmt);
												System.out.println("Amount Deposited Successfully Rs: "+userEnteredAmt);
												System.out.println();
												//System.out.println("Transaction ID : "+currBal.getInt(1));
												System.out.println("Your Currunt Balance : "+currBal);
											} catch (AccountException e) {
												// TODO Auto-generated catch block
												System.out.println(e.getMessage());
											}
											break;
				
										case 4:
											System.out.println("Enter your account number  :: ");
											long fromActNum=scan.nextLong();
											System.out.println("Enter Benificiery account number to transfer amount :: ");
											long toActNum=scan.nextLong();
											while(true)
											{
												System.out.println("Enter Amount to Transfer :: ");
												System.out.println("<<<<<<=============================================================>>>>>>");
												System.out.println("Amount Should be more than 0 and maximum 50000 Rs. ::");
												System.out.println();
												userEnteredAmt=scan.nextLong();
												boolean isAmtValid= service.validateWithdrawAmount(userEnteredAmt);
												if(isAmtValid)
												break;
												else
												{
													System.out.println("Invalid Amount");
												}
											}
											
											try {
												double currBal=service.fundTransfer(fromActNum,toActNum, userEnteredAmt);
												System.out.println("Amount Transfered Successfully Rs: "+userEnteredAmt);
												System.out.println();
												System.out.println("Your Currunt Balance : "+currBal);
											}
											catch (AccountException e) {
												// TODO Auto-generated catch block
												System.out.println(e.getMessage());
											}
											break;
											
										case 5:
											System.out.println("Enter Account num  for mini statement");
																long transActNum=scan.nextLong();
												try {
													
													service.printTransaction(transActNum);
													
													} catch (AccountException e) {
																// TODO Auto-generated catch block
																System.out.println(e.getMessage());
													}
											break;
											
										default :
											System.out.println("Invalid Input");
											
											break;
											
											}
												System.out.println();
												System.out.println("To continue 1 else 0");
												choice= scan.nextInt();
						
										}while(choice!=0);
												
			}
			System.out.println();
			System.out.println("To continue 1 else 0");
			choice= scan.nextInt();
		}while(choice!=0);

		scan.close();
	}

}
