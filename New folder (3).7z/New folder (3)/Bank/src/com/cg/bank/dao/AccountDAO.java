package com.cg.bank.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.cg.bank.bean.Customer;

import com.cg.bank.exception.AccountException;



public class AccountDAO implements IAccountDAO {
	 
	 String driver = "oracle.jdbc.driver.OracleDriver";
	  String url ="jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
	  String username = "lab2etrg12";
	  String password = "lab2eoracle";
	  
	  private static final String CUSTOMER_DB = "create table Customers2( "
		      + "   accNum INT PRIMARY KEY, name VARCHAR(20), phNum  VARCHAR(10), "
		      + "   addr VARCHAR(20), email VARCHAR(30), dob VARCHAR(10), gender VARCHAR(6), " 
		      + "   ifsc VARCHAR(10), branch VARCHAR(10), actBal INT" + ")"; 
	  
	  private static final String TRANS_DB = "create table Transactions2( "
		      + "   transId INT PRIMARY KEY, accNum INT, transType  VARCHAR(10), TransactionDate VARCHAR(30), initialAmount INT,"
		      + " transactionamount INT, finalAmount INT " + ")"; 
	  
	  public Statement getConnection() {
		  Connection conn = null;
		  Statement stmt =null;
		  try {
			  
		      Class.forName(driver);
		      conn = DriverManager.getConnection(url, username, password);
		      stmt = conn.createStatement();
		  
		     
		    } catch (ClassNotFoundException e) {
		      System.out.println("error: failed to load Oracle driver.");
		      e.printStackTrace();
		    } catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    } catch (Exception e) {
		      System.out.println("other error:");
		      e.printStackTrace();
		    } 
	
		  return stmt;
		  }
	  
	@Override
	public Customer createAccount(Customer customer) {
		// TODO Auto-generated method stub
		 long accNum= customer.getAccNum();
		    String name=customer.getName();
		    long phNum=customer.getPhNum();
		    String addr=customer.getAddr();
		    String email=customer.getEmail();
		    String dob=customer.getDob();
		    String gender=customer.getGender();
		    double dptAmt=customer.getDptAmt();
		   
		    String ifsc=customer.getIfsc();
		    String branch=customer.getBranch();
		    double actBal=customer.getActBal();
		    Statement stmt=null;
		    
		    try {
		 
		    	stmt=getConnection();
//		    	stmt.executeUpdate(CUSTOMER_DB);
//		     	stmt.executeUpdate(TRANS_DB);
		    	
		    	stmt.executeUpdate("insert into Customers2(accNum, name, phNum, addr, email, dob, gender, ifsc, branch, actBal ) "
		      		+ "values(" +accNum + ",'" + name + "','" + phNum +"','"+  addr + "','" + email  + "','" + dob + "','"  +  gender +"','"+  ifsc + "','" + branch +"',"+  actBal +")");
		     
		    	stmt.executeUpdate("insert into Transactions2(transId, accNum, transType, transactionDate, initialAmount, transactionAmount, finalAmount ) "
		      		+ "values(" + (int) (Math.random()*123456) +","+  accNum +"," + "'credit'" + ",'" + new Timestamp(new java.util.Date().getTime()) + "'," + 0 + "," + actBal + "," + actBal +")");
		      
		      System.out.println("CreateCustomerTableOracle: main(): table created.");
		    
		    } catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    } catch (Exception e) {
		      System.out.println("other error:");
		      e.printStackTrace();
		    }finally{
		    	try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
		    
		    return customer;
	}

	@Override
	public double showBal(long actNum) throws AccountException {
		
		double bal=0.0;
		try {
			Statement stmt=getConnection();
			ResultSet rslt =stmt.executeQuery("select * from customers2 where accNum="+actNum);
			
			 if (rslt.next()) {
		          bal=rslt.getDouble(10);
		      }
		      else
		      {
		    	  throw new AccountException("No Account Found with accoumt num: "+actNum);	
		      }
		      
		    } catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    } 
		return bal;
	}

	@Override
	public double withdraw(long actNum,double amt) throws AccountException {
	
		double bal1=0.0;
		try {
				Statement stmt=getConnection();
		     	ResultSet rslt=stmt.executeQuery("select * from customers2 where accNum="+actNum);

		      if (rslt.next()) {
		    	  
		        double bal= rslt.getDouble(10);
		        
			        if(amt<=bal)
			        {
			        	int transId=(int) (Math.random()*123456); 
				        double fBal=bal-amt;
				        stmt.executeUpdate("update Customers2 set actBal= " + fBal + "where accNum="+ actNum);
				        stmt.executeUpdate("insert into Transactions2(transId, accNum, transType, transactionDate, initialAmount, transactionAmount, finalAmount ) "
				        		+ "values(" + transId +","+  actNum +"," + "'debit'" + ",'" + new Timestamp(new java.util.Date().getTime()) + "'," + bal + "," + amt + "," + fBal +")");
				        
				        ResultSet  rslt1=stmt.executeQuery("select transId,finalAmount from Transactions2 where transId="+transId);

						 if (rslt1.next()) {
					         
					          System.out.println("Transaction ID: "+rslt1.getInt(1));
					          bal1=rslt1.getDouble(2);
					      }
			        }
			        else
			        {
			        	throw new AccountException("Insufficient Funds:: Available bal = "+bal);
			        }
			    	
		      }
		      else
		      {
		    	  throw new AccountException("Account Not found with account number : "+actNum);
		      }
		    
		    } catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    }  
		  return bal1;		
	}

	@Override
	public double deposite(long actNum,double amt) throws AccountException{
		
		double bal1=0.0;
		try {   
			 Statement stmt=getConnection();
		      ResultSet rslt=stmt.executeQuery("select * from customers2 where accNum="+actNum);

		      if (rslt.next()) {
		    	  int transId=(int) (Math.random()*123456); 
		        double bal= rslt.getDouble(10);
		       
		        double fBal=bal+amt;
		        stmt.executeUpdate("update Customers2 set actBal= " + fBal + "where accNum="+ actNum);
		        stmt.executeUpdate("insert into Transactions2(transId, accNum, transType, transactionDate, initialAmount, transactionAmount, finalAmount ) "
			        		+ "values(" + transId +","+  actNum +"," + "'credit'" + ",'" + new Timestamp(new java.util.Date().getTime()) + "'," + bal + "," + amt + "," + fBal +")");
		      	
		      	ResultSet rslt1=stmt.executeQuery("select transId,finalAmount from Transactions2 where transId="+transId);
		      	 if (rslt1.next()) {
			         
			          System.out.println("Transaction ID: "+rslt1.getInt(1));
			          bal1=rslt1.getDouble(2);
			      }
		      }
		      else
		      {
		    	  throw new AccountException("Account Not found with account number : "+actNum);  
		      }
			}catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    } 
		return bal1;      
	}

	@Override
	public double fundTransfer(long fromActNum, long toActNum, double amt) throws AccountException {
		// TODO Auto-generated method stub
		double bal1=0.0;
		
		try {
			if(fromActNum != toActNum){
		      Statement stmt=getConnection();
		      ResultSet rslt=stmt.executeQuery("select * from customers2 where accNum="+fromActNum);
		      

		      if (rslt.next()) {
		    	  double fromBal= rslt.getDouble(10);
		    	  
		    	  ResultSet rslt1=stmt.executeQuery("select * from customers2 where accNum="+toActNum);
		    	 
		    	  if (rslt1.next()) {
		    		  double toBal= rslt1.getDouble(10);
		    		  
		    		  int transId=(int) (Math.random()*123456); 
			       
			        	if(amt<=fromBal){
						        double finalFromBal=fromBal-amt;
						        stmt.executeUpdate("update Customers2 set actBal= " + finalFromBal + "where accNum="+ fromActNum);
						        stmt.executeUpdate("insert into Transactions2(transId, accNum, transType, transactionDate, initialAmount, transactionAmount, finalAmount ) "
						        		+ "values(" + transId +","+  fromActNum +"," + "'debit'" + ",'" + new Timestamp(new java.util.Date().getTime()) + "'," + fromBal + "," + amt + "," + finalFromBal +")");
						
						    	int transId1=(int) (Math.random()*123456);
						    	
						        double finalToBal=toBal+amt;
						      	stmt.executeUpdate("update Customers2 set actBal= " + finalToBal + "where accNum="+ toActNum);
						      	stmt.executeUpdate("insert into Transactions2(transId, accNum, transType, transactionDate, initialAmount, transactionAmount, finalAmount ) "
						        		+ "values(" + transId1 +","+  toActNum +"," + "'credit'" + ",'" + new Timestamp(new java.util.Date().getTime()) + "'," + toBal + "," + amt + "," + finalToBal +")");
						      	ResultSet rslt2=stmt.executeQuery("select transId,finalAmount from Transactions2 where transId="+transId);
						      	
						      	if (rslt2.next()) {
							         // System.out.println(rslt.getDouble(10));
							          System.out.println("Transaction ID: "+rslt2.getInt(1));
							          bal1=rslt2.getDouble(2);
							      }
					      } else
					        {
					        	throw new AccountException("Insufficient funds :: Available Bal: "+fromBal); 
					        }   
				      }
			    	  else
				      {
				    	  throw new AccountException("Account Not found with account number : "+toActNum);
				      }
		        	
			      }
			      else
			      {
			    	  throw new AccountException("Account Not found with account number : "+fromActNum);
			      } 
				}
			 else
		      {
		    	  throw new AccountException("From ActNum & To ActNum Should NOT BE SAME");
		      } 
		    } catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    }
		return bal1;
					
	}

	@Override
	public void printTransaction(long actNum) throws AccountException{
		
		try {
			  
		 	ResultSet rslt=getConnection().executeQuery("select * from Transactions2 where accNum="+actNum);

		 	if(rslt.next()){
		 		
		 		System.out.println("TrnsId" + "ActNum " + "Action " + "TransactionDate & Time  " + "IniAmt " + "TrnAmt " + "finAmt "); 
		 		
		      while (rslt.next()) {
		    	
		        System.out.print(rslt.getInt(1)+" ");
		        System.out.print(rslt.getInt(2)+" ");
		        System.out.print(rslt.getString(3)+" ");
		        System.out.print(rslt.getString(4)+" ");
		        System.out.print(rslt.getInt(5)+" ");
		        System.out.print(rslt.getInt(6)+" ");
		        System.out.print(rslt.getInt(7)+" ");
		        System.out.println();
		        
		      }
		 	}
		 	else
		 	{
		 		throw new AccountException("Account Not found with account number : "+actNum);
		 	}
		      
		    } catch (SQLException e) {
		      System.out.println("error: failed to create a connection object.");
		      e.printStackTrace();
		    } 
		}
}
