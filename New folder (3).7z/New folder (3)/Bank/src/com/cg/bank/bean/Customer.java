package com.cg.bank.bean;


public class Customer {
	
	private String name;
	private long phNum;
	private String addr;
	private String email;
	private String dob;
	private String gender;
	
	private  long accNum;
	private String ifsc;
	private String branch;
	private double actBal;

	private double dptAmt;
	

	public Customer(long actNum)
	{
		this.accNum=actNum;
	}
	public Customer(String name, long phNum, String addr, String email,
			String dob, String gender,double dptAmt) {
		super();
		this.name = name;
		this.phNum = phNum;
		this.addr = addr;
		this.email = email;
		this.dob = dob;
		this.gender = gender;
		
		accNum = (long) (Math.random()*123456789);
		this.ifsc = "XYZ000854";
		this.branch = "Airoli";
		
		setActBal(dptAmt);
	}
	public Customer()
	{
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhNum() {
		return phNum;
	}
	public void setPhNum(long phNum) {
		this.phNum = phNum;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public double getDptAmt() {
		return dptAmt;
	}

	public void setDptAmt(double dptAmt) {
		this.dptAmt = dptAmt;
	}
	
	
	public long getAccNum() {
		return accNum;
	}
	public String getIfsc() {
		return ifsc;
	}
	public String getBranch() {
		return branch;
	}
	public double getActBal() {
		return actBal;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public void setActBal(double actBal) {
		this.actBal = actBal;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", phNum=" + phNum + ", addr=" + addr
				+ ", email=" + email + ", dob=" + dob + ", gender=" + gender
				+ ", accNum=" + accNum + ", ifsc=" + ifsc + ", branch="
				+ branch + ", actBal=" + actBal + ", dptAmt=" + dptAmt + "]";
	}
	
	
		
	

}
